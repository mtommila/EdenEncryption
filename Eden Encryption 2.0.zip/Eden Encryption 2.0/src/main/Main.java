package main;

public class Main {

	public static void main(String[] args) {
		//Separate class as I could not use 'this' when in static
		new EdenEncryption();
	}

}
